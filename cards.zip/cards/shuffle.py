import tkinter as tk
from PIL import Image, ImageTk
import random
import os

# Define the path to the image folder
IMAGE_FOLDER = 'images/'

# List of card image filenames
CARD_IMAGES = [
    '2_of_diamonds.jpg',
    '3_of_diamonds.jpg',
    '4_of_diamonds.jpg',
    '5_of_diamonds.jpg',
    '6_of_diamonds.jpg',
    '7_of_diamonds.jpg',
    '8_of_diamonds.jpg',
    '9_of_diamonds.jpg',
    '10_of_diamonds.jpg',
    'jack_of_diamonds.jpg',
    'queen_of_diamonds.jpg',
    'king_of_diamonds2.jpg',
    'ace_of_diamonds.jpg',
    '2_of_clubs.jpg',
    '3_of_clubs.jpg',
    '4_of_clubs.jpg',
    '5_of_clubs.jpg',
    '6_of_clubs.jpg',
    '7_of_clubs.jpg',
    '8_of_clubs.jpg',
    '9_of_clubs.jpg',
    '10_of_clubs.jpg',
    'jack_of_clubs.jpg',
    'queen_of_clubs.jpg',
    'king_of_clubs2.jpg',
    'ace_of_clubs.jpg',
    '2_of_spades.jpg',
    '3_of_spades.jpg',
    '4_of_spades.jpg',
    '5_of_spades.jpg',
    '6_of_spades.jpg',
    '7_of_spades.jpg',
    '8_of_spades.jpg',
    '9_of_spades.jpg',
    '10_of_spades.jpg',
    'jack_of_spades.jpg',
    'queen_of_spades.jpg',
    'king_of_spades2.jpg',
    'ace_of_spades.jpg',
    '2_of_hearts.jpg',
    '3_of_hearts.jpg',
    '4_of_hearts.jpg',
    '5_of_hearts.jpg',
    '6_of_hearts.jpg',
    '7_of_hearts.jpg',
    '8_of_hearts.jpg',
    '9_of_hearts.jpg',
    '10_of_hearts.jpg',
    'jack_of_hearts.jpg',
    'queen_of_hearts.jpg',
    'king_of_hearts2.jpg',
    'ace_of_hearts.jpg'
]

# Initialize the main window
root = tk.Tk()
root.title("Card Shuffler")

# Create a frame to hold the cards
card_frame = tk.Frame(root)
card_frame.pack(pady=20)

# Load and resize all card images using Pillow
cards = []
for img in CARD_IMAGES:
    original_image = Image.open(os.path.join(IMAGE_FOLDER, img))
    resized_image = original_image.resize((int(original_image.width * 0.25), int(original_image.height * 0.25)))  # Resize to 25%
    cards.append(ImageTk.PhotoImage(resized_image))

# Create a list to hold the label references for the cards
card_labels = []

# Function to display the cards in a grid
def display_cards():
    for i in range(len(cards)):
        row = i // 13  # 13 cards per row
        col = i % 13   # column position
        label = tk.Label(card_frame, image=cards[i])
        label.grid(row=row, column=col, padx=5, pady=5)
        card_labels.append(label)

# Shuffle function to rearrange card display
def shuffle_cards():
    random.shuffle(cards)
    for i in range(len(cards)):
        card_labels[i].config(image=cards[i])

# Display the cards in the initial layout
display_cards()

# Create a button to shuffle the cards
shuffle_button = tk.Button(root, text="Shuffle Cards", command=shuffle_cards)
shuffle_button.pack(pady=20)

# Start the Tkinter main loop
root.mainloop()
