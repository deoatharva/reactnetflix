import tkinter as tk
from tkinter import messagebox
import random

class Sudoku:
    def __init__(self, root):
        self.root = root
        self.root.title("Sudoku Solver")
        self.board = [[0 for _ in range(9)] for _ in range(9)]
        self.create_board()
        self.generate_sudoku()

    def create_board(self):
        self.entries = [[None for _ in range(9)] for _ in range(9)]
        for i in range(9):
            for j in range(9):
                entry = tk.Entry(self.root, width=2, font=('Arial', 24), justify='center')
                entry.grid(row=i, column=j, padx=5, pady=5)
                self.entries[i][j] = entry

        solve_button = tk.Button(self.root, text="Solve", command=self.solve_sudoku)
        solve_button.grid(row=10, column=0, columnspan=9)

    def print_board(self):
        for i in range(9):
            for j in range(9):
                value = self.entries[i][j].get()
                self.board[i][j] = int(value) if value.isdigit() and 1 <= int(value) <= 9 else 0

    def is_valid(self, row, col, num):
        for i in range(9):
            if self.board[row][i] == num or self.board[i][col] == num:
                return False
        start_row, start_col = 3 * (row // 3), 3 * (col // 3)
        for i in range(3):
            for j in range(3):
                if self.board[start_row + i][start_col + j] == num:
                    return False
        return True

    def solve(self):
        for row in range(9):
            for col in range(9):
                if self.board[row][col] == 0:
                    for num in range(1, 10):
                        if self.is_valid(row, col, num):
                            self.board[row][col] = num
                            if self.solve():
                                return True
                            self.board[row][col] = 0
                    return False
        return True

    def solve_sudoku(self):
        self.print_board()
        if self.solve():
            self.fill_entries()
        else:
            messagebox.showinfo("No Solution", "No solution exists.")

    def fill_entries(self):
        for i in range(9):
            for j in range(9):
                self.entries[i][j].delete(0, tk.END)
                if self.board[i][j] != 0:
                    self.entries[i][j].insert(0, str(self.board[i][j]))

    def fill_board(self):
        for i in range(9):
            for j in range(9):
                if self.board[i][j] == 0:
                    num = random.randint(1, 9)
                    if self.is_valid(i, j, num):
                        self.board[i][j] = num
                        if self.fill_board():
                            return True
                        self.board[i][j] = 0
                    return False
        return True

    def generate_sudoku(self):
        self.fill_board()
        # Remove some numbers to create the puzzle
        for _ in range(random.randint(40, 60)):
            x, y = random.randint(0, 8), random.randint(0, 8)
            self.board[x][y] = 0
        self.fill_entries()

if __name__ == "__main__":
    root = tk.Tk()
    sudoku = Sudoku(root)
    root.mainloop()
