import tkinter as tk
from tkinter import messagebox
import random

# Constants for the board size and pieces
BOARD_SIZE = 8
EMPTY = None
WHITE_PIECES = {'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙'}
BLACK_PIECES = {'K': '♚', 'Q': '♛', 'R': '♜', 'B': '♞', 'N': '♟', 'P': '♟'}

class ChessGame:
    def __init__(self):
        self.board = self.initialize_board()
        self.selected_piece = None
        self.selected_position = None

    def initialize_board(self):
        board = [[EMPTY for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]
        # Place the pieces on the board
        board[0] = [BLACK_PIECES['R'], BLACK_PIECES['N'], BLACK_PIECES['B'], BLACK_PIECES['Q'],
                     BLACK_PIECES['K'], BLACK_PIECES['B'], BLACK_PIECES['N'], BLACK_PIECES['R']]
        board[1] = [BLACK_PIECES['P'] for _ in range(BOARD_SIZE)]
        board[6] = [WHITE_PIECES['P'] for _ in range(BOARD_SIZE)]
        board[7] = [WHITE_PIECES['R'], WHITE_PIECES['N'], WHITE_PIECES['B'], WHITE_PIECES['Q'],
                     WHITE_PIECES['K'], WHITE_PIECES['B'], WHITE_PIECES['N'], WHITE_PIECES['R']]
        return board

    def move_piece(self, from_pos, to_pos):
        piece = self.board[from_pos[0]][from_pos[1]]
        self.board[to_pos[0]][to_pos[1]] = piece
        self.board[from_pos[0]][from_pos[1]] = EMPTY

    def is_valid_move(self, from_pos, to_pos):
        # Basic validation: check within bounds and if moving to an empty space
        return (0 <= to_pos[0] < BOARD_SIZE and 0 <= to_pos[1] < BOARD_SIZE)

    def get_piece(self, pos):
        return self.board[pos[0]][pos[1]]

    def ai_move(self):
        # Simple AI: randomly pick a valid move for a black piece
        valid_moves = []
        for r in range(BOARD_SIZE):
            for c in range(BOARD_SIZE):
                piece = self.get_piece((r, c))
                if piece in BLACK_PIECES.values():  # If it's a black piece
                    for new_r in range(BOARD_SIZE):
                        for new_c in range(BOARD_SIZE):
                            if self.is_valid_move((r, c), (new_r, new_c)):
                                valid_moves.append(((r, c), (new_r, new_c)))
        
        if valid_moves:
            from_pos, to_pos = random.choice(valid_moves)
            self.move_piece(from_pos, to_pos)

class ChessApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Chess Game with AI")
        self.game = ChessGame()
        self.create_widgets()
        self.draw_board()

    def create_widgets(self):
        self.canvas = tk.Canvas(self.root, width=400, height=400)
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self.on_canvas_click)

    def draw_board(self):
        self.canvas.delete("all")
        for row in range(BOARD_SIZE):
            for col in range(BOARD_SIZE):
                color = "white" if (row + col) % 2 == 0 else "gray"
                self.canvas.create_rectangle(col * 50, row * 50, (col + 1) * 50, (row + 1) * 50, fill=color)
                piece = self.game.get_piece((row, col))
                if piece:
                    self.canvas.create_text(col * 50 + 25, row * 50 + 25, text=piece, font=("Arial", 24))

    def on_canvas_click(self, event):
        col = event.x // 50
        row = event.y // 50
        if self.game.selected_piece is None:
            piece = self.game.get_piece((row, col))
            if piece in WHITE_PIECES.values():  # Select only white pieces
                self.game.selected_piece = piece
                self.game.selected_position = (row, col)
        else:
            from_pos = self.game.selected_position
            to_pos = (row, col)
            if self.game.is_valid_move(from_pos, to_pos):
                self.game.move_piece(from_pos, to_pos)
                self.draw_board()
                self.game.ai_move()  # AI makes a move
                self.draw_board()
            self.game.selected_piece = None
            self.game.selected_position = None

if __name__ == "__main__":
    root = tk.Tk()
    app = ChessApp(root)
    root.mainloop()
