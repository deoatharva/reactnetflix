import tkinter as tk
from collections import defaultdict

class Graph:
    def __init__(self):
        self.graph = defaultdict(list)
        self.path = []
        self.index = -1

    def addEdge(self, u, v):
        self.graph[u].append(v)

    def DFSUtil(self, v, visited):
        visited.add(v)
        self.path.append(v)
        for neighbour in self.graph[v]:
            if neighbour not in visited:
                self.DFSUtil(neighbour, visited)

    def DFS(self, v):
        visited = set()
        self.path = []
        self.index = -1
        self.DFSUtil(v, visited)

class GraphGUI(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.graph = graph
        self.title("Graph DFS Traversal")
        self.geometry("400x300")
        self.canvas = tk.Canvas(self, width=400, height=300, bg="white")
        self.canvas.pack()

        self.button_forward = tk.Button(self, text="Forward", command=self.move_forward)
        self.button_forward.pack(side=tk.LEFT)

        self.button_backward = tk.Button(self, text="Backward", command=self.move_backward)
        self.button_backward.pack(side=tk.RIGHT)

        self.node_positions = {
            0: (50, 150),
            1: (150, 50),
            2: (150, 250),
            3: (250, 150)
        }
        self.draw_graph()
        self.current_node = None
        self.draw_ball()

    def draw_graph(self):
        for node, pos in self.node_positions.items():
            x, y = pos
            self.canvas.create_oval(x-10, y-10, x+10, y+10, fill="blue")
            self.canvas.create_text(x, y, text=str(node), fill="white")
        
        self.canvas.create_line(50, 150, 150, 50, arrow=tk.LAST)
        self.canvas.create_line(50, 150, 150, 250, arrow=tk.LAST)
        self.canvas.create_line(150, 50, 250, 150, arrow=tk.LAST)
        self.canvas.create_line(150, 250, 250, 150, arrow=tk.LAST)
        self.canvas.create_line(250, 150, 250, 150, arrow=tk.LAST)

    def draw_ball(self):
        if self.current_node is not None:
            x, y = self.node_positions[self.current_node]
            self.ball = self.canvas.create_oval(x-10, y-10, x+10, y+10, fill="red")

    def move_ball(self):
        if self.current_node is not None:
            x, y = self.node_positions[self.current_node]
            self.canvas.coords(self.ball, x-10, y-10, x+10, y+10)

    def move_forward(self):
        if self.graph.index < len(self.graph.path) - 1:
            self.graph.index += 1
            self.current_node = self.graph.path[self.graph.index]
            self.move_ball()

    def move_backward(self):
        if self.graph.index > 0:
            self.graph.index -= 1
            self.current_node = self.graph.path[self.graph.index]
            self.move_ball()

if __name__ == "__main__":
    g = Graph()
    g.addEdge(0, 1)
    g.addEdge(0, 2)
    g.addEdge(1, 2)
    g.addEdge(2, 0)
    g.addEdge(2, 3)
    g.addEdge(3, 3)
    g.DFS(2)

    app = GraphGUI(g)
    app.mainloop()
