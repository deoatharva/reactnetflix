import tkinter as tk
from tkinter import scrolledtext
from BlockWorldAgent import BlockWorldAgent

class BlockWorldGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Block World Solver")

        self.agent = BlockWorldAgent()

        # Input for initial arrangement
        self.initial_label = tk.Label(root, text="Initial Arrangement:")
        self.initial_label.pack()
        self.initial_text = tk.Text(root, height=5, width=50)
        self.initial_text.pack()

        # Input for goal arrangement
        self.goal_label = tk.Label(root, text="Goal Arrangement:")
        self.goal_label.pack()
        self.goal_text = tk.Text(root, height=5, width=50)
        self.goal_text.pack()

        # Solve button
        self.solve_button = tk.Button(root, text="Solve", command=self.solve)
        self.solve_button.pack()

        # Output area
        self.output_area = scrolledtext.ScrolledText(root, height=10, width=50)
        self.output_area.pack()

    def solve(self):
        initial_arrangement = self.parse_input(self.initial_text.get("1.0", tk.END))
        goal_arrangement = self.parse_input(self.goal_text.get("1.0", tk.END))

        if initial_arrangement and goal_arrangement:
            result = self.agent.solve(initial_arrangement, goal_arrangement)
            self.output_area.insert(tk.END, f"Result: {result}\n")
        else:
            self.output_area.insert(tk.END, "Invalid input. Please check your arrangements.\n")

    def parse_input(self, input_str):
        try:
            return eval(input_str.strip())
        except Exception:
            return None

if __name__ == "__main__":
    root = tk.Tk()
    app = BlockWorldGUI(root)
    root.mainloop()
