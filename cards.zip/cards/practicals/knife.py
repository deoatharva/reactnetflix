import pygame
import sys
import math
import random

# Initialize Pygame
pygame.init()

# Constants
WIDTH, HEIGHT = 800, 600
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
KNIFE_RADIUS = 5
TARGET_RADIUS = 20
TARGET_COUNT = 5

# Create the display window
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Knife Thrower")

# Clock for controlling the frame rate
clock = pygame.time.Clock()

class Knife:
    def __init__(self, x, y, angle, speed):
        self.x = x
        self.y = y
        self.angle = angle
        self.speed = speed
        self.dx = speed * math.cos(angle)
        self.dy = speed * math.sin(angle)

    def update(self):
        self.x += self.dx
        self.y -= self.dy  # y decreases as we go up
        self.dy -= 0.1  # Simulate gravity

    def draw(self):
        pygame.draw.circle(screen, RED, (int(self.x), int(self.y)), KNIFE_RADIUS)

class Target:
    def __init__(self):
        self.x = random.randint(TARGET_RADIUS, WIDTH - TARGET_RADIUS)
        self.y = random.randint(TARGET_RADIUS, HEIGHT - TARGET_RADIUS)
    
    def draw(self):
        pygame.draw.circle(screen, BLACK, (self.x, self.y), TARGET_RADIUS)

def check_collision(knife, target):
    distance = math.sqrt((knife.x - target.x) ** 2 + (knife.y - target.y) ** 2)
    return distance < KNIFE_RADIUS + TARGET_RADIUS

def main():
    knives = []
    targets = [Target() for _ in range(TARGET_COUNT)]
    score = 0
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                angle = math.atan2(mouse_y - HEIGHT // 2, mouse_x - WIDTH // 2)
                speed = 10
                knives.append(Knife(WIDTH // 2, HEIGHT // 2, angle, speed))
        
        # Update knife positions
        for knife in knives[:]:
            knife.update()
            if knife.x < 0 or knife.x > WIDTH or knife.y < 0 or knife.y > HEIGHT:
                knives.remove(knife)
        
        # Check for collisions
        for knife in knives[:]:
            for target in targets:
                if check_collision(knife, target):
                    targets.remove(target)
                    knives.remove(knife)
                    score += 1
                    break
        
        # Drawing
        screen.fill(WHITE)
        for knife in knives:
            knife.draw()
        for target in targets:
            target.draw()
        
        # Display score
        font = pygame.font.Font(None, 36)
        text = font.render(f"Score: {score}", True, BLACK)
        screen.blit(text, (10, 10))
        
        pygame.display.flip()
        clock.tick(60)

if __name__ == "__main__":
    main()
