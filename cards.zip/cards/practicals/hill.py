import tkinter as tk
import numpy as np
from itertools import permutations

class TSPGame:
    def __init__(self, master):
        self.master = master
        master.title("Traveling Salesman Problem Game")

        self.canvas = tk.Canvas(master, width=600, height=600, bg='white')
        self.canvas.pack()

        self.cities = []
        self.num_cities = 5
        self.create_cities()

        self.draw_cities()

        self.solve_button = tk.Button(master, text="Solve TSP", command=self.solve_tsp)
        self.solve_button.pack()

        self.reset_button = tk.Button(master, text="Reset", command=self.reset)
        self.reset_button.pack()

    def create_cities(self):
        for _ in range(self.num_cities):
            x = np.random.randint(50, 550)
            y = np.random.randint(50, 550)
            self.cities.append((x, y))

    def draw_cities(self):
        self.canvas.delete("all")
        for (x, y) in self.cities:
            self.canvas.create_oval(x - 5, y - 5, x + 5, y + 5, fill='blue')

    def calculate_distance(self, city1, city2):
        return np.linalg.norm(np.array(city1) - np.array(city2))

    def total_distance(self, path):
        return sum(self.calculate_distance(self.cities[path[i]], self.cities[path[i - 1]]) for i in range(len(path)))

    def solve_tsp(self):
        best_path = None
        min_distance = float('inf')

        for perm in permutations(range(self.num_cities)):
            distance = self.total_distance(perm)
            if distance < min_distance:
                min_distance = distance
                best_path = perm

        self.draw_best_path(best_path)

    def draw_best_path(self, path):
        for i in range(len(path)):
            x1, y1 = self.cities[path[i]]
            x2, y2 = self.cities[path[(i + 1) % len(path)]]
            self.canvas.create_line(x1, y1, x2, y2, fill='red', width=2)

    def reset(self):
        self.cities = []
        self.create_cities()
        self.draw_cities()

if __name__ == "__main__":
    root = tk.Tk()
    tsp_game = TSPGame(root)
    root.mainloop()
