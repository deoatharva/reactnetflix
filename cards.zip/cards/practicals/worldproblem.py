import tkinter as tk
from tkinter import messagebox

class BlockWorld:
    def __init__(self, master):
        self.master = master
        self.master.title("Block World Problem")

        # Initial arrangement
        self.blocks = ['A', 'B', 'C']
        self.peg_stack = {0: self.blocks.copy(), 1: [], 2: [], 3: []}  # 0th peg has A, B, C

        self.canvas = tk.Canvas(master, width=400, height=400, bg="white")
        self.canvas.pack()

        self.draw_blocks()
        self.canvas.bind("<Button-1>", self.on_click)

    def draw_blocks(self):
        self.canvas.delete("all")
        for peg, stack in self.peg_stack.items():
            y = 350 - len(stack) * 30  # Calculate y position
            for index, block in enumerate(stack):
                self.canvas.create_rectangle(50 + peg * 100, y + index * 30,
                                              150 + peg * 100, y + index * 30 + 30,
                                              fill="lightblue")
                self.canvas.create_text(100 + peg * 100, y + index * 30 + 15, text=block)

    def on_click(self, event):
        x, y = event.x, event.y
        peg = x // 100
        if peg < 4:
            if self.peg_stack[peg]:
                block = self.peg_stack[peg].pop()  # Remove the top block
                # Move to the next peg (for demonstration, moving to peg 1)
                self.peg_stack[1].append(block)
            self.draw_blocks()
            self.check_goal()

    def check_goal(self):
        # Check if the arrangement is C, A, B on peg 1
        if self.peg_stack[1] == ['C', 'A', 'B']:
            messagebox.showinfo("Success", "You have achieved the goal: C, A, B!")

if __name__ == "__main__":
    root = tk.Tk()
    app = BlockWorld(root)
    root.mainloop()
