import tkinter as tk
from tkinter import messagebox, font
import numpy as np

# Define the Connect Four game
class ConnectFour:
    def __init__(self):
        self.board = np.zeros((6, 7), int)  # 6 rows, 7 columns
        self.current_player = 1  # Player 1 is 1, AI is 2

    def drop_piece(self, col, player):
        for row in reversed(range(6)):
            if self.board[row][col] == 0:
                self.board[row][col] = player
                return True
        return False

    def is_winner(self, player):
        # Check horizontal, vertical, and diagonal for a win
        for c in range(7):
            for r in range(6):
                if self.check_winner(r, c, player):
                    return True
        return False

    def check_winner(self, row, col, player):
        if col + 3 < 7 and all(self.board[row][col+i] == player for i in range(4)):
            return True
        if row + 3 < 6:
            if all(self.board[row+i][col] == player for i in range(4)):
                return True
            if col + 3 < 7 and all(self.board[row+i][col+i] == player for i in range(4)):
                return True
            if col - 3 >= 0 and all(self.board[row+i][col-i] == player for i in range(4)):
                return True
        return False

    def is_full(self):
        return np.all(self.board != 0)

    def get_valid_moves(self):
        return [c for c in range(7) if self.board[0][c] == 0]

    def clone(self):
        new_game = ConnectFour()
        new_game.board = self.board.copy()
        return new_game

# Alpha-Beta pruning implementation
def alpha_beta(game, depth, alpha, beta, maximizing_player):
    if depth == 0 or game.is_winner(1) or game.is_winner(2) or game.is_full():
        return evaluate(game)

    if maximizing_player:
        max_eval = float('-inf')
        for col in game.get_valid_moves():
            new_game = game.clone()
            new_game.drop_piece(col, 2)  # AI plays as 2
            eval = alpha_beta(new_game, depth - 1, alpha, beta, False)
            max_eval = max(max_eval, eval)
            alpha = max(alpha, eval)
            if beta <= alpha:
                break
        return max_eval
    else:
        min_eval = float('inf')
        for col in game.get_valid_moves():
            new_game = game.clone()
            new_game.drop_piece(col, 1)  # Player plays as 1
            eval = alpha_beta(new_game, depth - 1, alpha, beta, True)
            min_eval = min(min_eval, eval)
            beta = min(beta, eval)
            if beta <= alpha:
                break
        return min_eval

def evaluate(game):
    if game.is_winner(2):
        return 1000
    elif game.is_winner(1):
        return -1000
    else:
        return 0

# GUI Application
class ConnectFourApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Connect Four with Alpha-Beta Pruning")
        self.root.geometry("700x600")
        self.root.configure(bg="lightblue")

        self.game = ConnectFour()

        self.canvas = tk.Canvas(root, width=700, height=600, bg="blue")
        self.canvas.pack()

        self.reset_button = tk.Button(root, text="Reset Game", font=('Arial', 14), bg="orange", command=self.reset_game)
        self.reset_button.pack(pady=20)

        self.draw_board()

        self.canvas.bind("<Button-1>", self.player_move)

    def draw_board(self):
        self.canvas.delete("all")
        for r in range(6):
            for c in range(7):
                color = "white" if self.game.board[r][c] == 0 else "red" if self.game.board[r][c] == 1 else "yellow"
                self.canvas.create_oval(c * 100 + 10, r * 100 + 10, c * 100 + 90, r * 100 + 90, fill=color)

    def player_move(self, event):
        col = event.x // 100
        if col in self.game.get_valid_moves():
            self.game.drop_piece(col, 1)
            self.draw_board()
            if self.game.is_winner(1):
                messagebox.showinfo("Game Over", "Player 1 wins!")
                self.reset_game()
            elif not self.game.is_full():
                self.ai_move()

    def ai_move(self):
        best_col = None
        best_score = float('-inf')
        for col in self.game.get_valid_moves():
            new_game = self.game.clone()
            new_game.drop_piece(col, 2)  # AI plays as 2
            score = alpha_beta(new_game, 3, float('-inf'), float('inf'), False)
            if score > best_score:
                best_score = score
                best_col = col

        if best_col is not None:
            self.game.drop_piece(best_col, 2)
            self.draw_board()
            if self.game.is_winner(2):
                messagebox.showinfo("Game Over", "AI wins!")
                self.reset_game()
            elif self.game.is_full():
                messagebox.showinfo("Game Over", "It's a draw!")
                self.reset_game()

    def reset_game(self):
        self.game = ConnectFour()
        self.draw_board()

if __name__ == "__main__":
    root = tk.Tk()
    app = ConnectFourApp(root)
    root.mainloop()
