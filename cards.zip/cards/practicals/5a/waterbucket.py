import tkinter as tk
from tkinter import messagebox

GOAL = 4  # The exact amount of water to have in a bucket to win.
steps = 0  # Keep track of how many steps the player made to solve this.
waterInBucket = {'8': 0, '5': 0, '3': 0}  # The amount of water in each bucket.

def update_display():
    # Update the display of buckets in the GUI
    canvas.delete("all")  # Clear previous display

    x_offset = 50
    y_offset = 30
    spacing = 50
    bucket_size = {'8': 8, '5': 5, '3': 3}

    for key, value in waterInBucket.items():
        canvas.create_text(x_offset, y_offset - 20, text=key + "L", anchor=tk.W)
        for i in range(bucket_size[key]):
            if value > i:
                canvas.create_rectangle(x_offset - 15, y_offset + (bucket_size[key] - i - 1) * 30,
                                        x_offset + 15, y_offset + (bucket_size[key] - i) * 30, fill="blue")
            else:
                canvas.create_rectangle(x_offset - 15, y_offset + (bucket_size[key] - i - 1) * 30,
                                        x_offset + 15, y_offset + (bucket_size[key] - i) * 30, fill="white")
        x_offset += spacing

    canvas.pack()

def fill_bucket(bucket):
    waterInBucket[bucket] = int(bucket)
    update_display()

def empty_bucket(bucket):
    waterInBucket[bucket] = 0
    update_display()

def pour(src_bucket, dst_bucket):
    src_size = int(src_bucket)
    dst_size = int(dst_bucket)

    space_in_dst = dst_size - waterInBucket[dst_bucket]
    water_to_pour = min(space_in_dst, waterInBucket[src_bucket])

    waterInBucket[src_bucket] -= water_to_pour
    waterInBucket[dst_bucket] += water_to_pour

    update_display()

def check_win():
    for waterAmount in waterInBucket.values():
        if waterAmount == GOAL:
            messagebox.showinfo("Congratulations!", f"You solved it in {steps} steps!")
            root.destroy()
            break

def make_move(action, top_var):
    global steps
    bucket = top_var.get()  # Get the actual string value from StringVar
    if action == 'F':
        fill_bucket(bucket)
    elif action == 'E':
        empty_bucket(bucket)
    elif action == 'P':
        pour(bucket, top.get())

    steps += 1
    check_win()

root = tk.Tk()
root.title("Water Bucket Puzzle")

canvas = tk.Canvas(root, width=200, height=300)

# Buttons for actions
fill_button = tk.Button(root, text="Fill", command=lambda: make_move('F', top))
fill_button.pack(side=tk.LEFT, padx=10)

empty_button = tk.Button(root, text="Empty", command=lambda: make_move('E', top))
empty_button.pack(side=tk.LEFT, padx=10)

pour_button = tk.Button(root, text="Pour", command=lambda: make_move('P', top))
pour_button.pack(side=tk.LEFT, padx=10)

# Dropdown menu to select the source bucket for pouring
top = tk.StringVar(root)
top.set('8')  # Default value

dropdown = tk.OptionMenu(root, top, '8', '5', '3')
dropdown.pack(side=tk.LEFT, padx=10)

update_display()

root.mainloop()
