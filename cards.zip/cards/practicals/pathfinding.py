import tkinter as tk
from tkinter import messagebox

# Maze layout
maze = [
    "#########",
    "#S#     #",
    "# # ### #",
    "# # #F  #",
    "# # ### #",
    "#       #",
    "#########"
]

# Player's starting position
player_pos = [1, 1]

# Directions
DIRECTIONS = {
    'Up': (0, -1),
    'Down': (0, 1),
    'Left': (-1, 0),
    'Right': (1, 0)
}

# Create the main application window
class MazeGame(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Maze Game")
        self.geometry("400x400")
        self.canvas = tk.Canvas(self, width=400, height=400)
        self.canvas.pack()
        self.draw_maze()
        self.bind("<KeyPress>", self.key_pressed)

    def draw_maze(self):
        self.canvas.delete("all")
        cell_size = 40
        for y, row in enumerate(maze):
            for x, char in enumerate(row):
                if char == '#':
                    self.canvas.create_rectangle(x * cell_size, y * cell_size,
                                                  (x + 1) * cell_size, (y + 1) * cell_size,
                                                  fill="black")
                elif char == 'S':
                    self.canvas.create_rectangle(x * cell_size, y * cell_size,
                                                  (x + 1) * cell_size, (y + 1) * cell_size,
                                                  fill="green")
                elif char == 'F':
                    self.canvas.create_rectangle(x * cell_size, y * cell_size,
                                                  (x + 1) * cell_size, (y + 1) * cell_size,
                                                  fill="red")
        # Draw player centered
        px, py = player_pos
        self.canvas.create_oval(px * cell_size + 10, py * cell_size + 10,
                                 (px + 1) * cell_size - 10, (py + 1) * cell_size - 10,
                                 fill="blue")

    def move_player(self, direction):
        global player_pos
        new_pos = [player_pos[0] + direction[0], player_pos[1] + direction[1]]

        if 0 <= new_pos[0] < len(maze[0]) and 0 <= new_pos[1] < len(maze):
            if maze[new_pos[1]][new_pos[0]] != '#':
                player_pos = new_pos
                if maze[player_pos[1]][player_pos[0]] == 'F':
                    messagebox.showinfo("Congratulations!", "You've reached the finish!")
                    self.quit()
                self.draw_maze()

    def key_pressed(self, event):
        if event.keysym in DIRECTIONS:
            self.move_player(DIRECTIONS[event.keysym])

if __name__ == "__main__":
    app = MazeGame()
    app.mainloop()
