import tkinter as tk
from tkinter import messagebox

class BlockWorld:
    def __init__(self):
        self.stacks = {0: [], 1: [], 2: []}
        self.create_initial_state()

    def create_initial_state(self):
        # Initial configuration
        self.stacks[0] = ['A', 'B']
        self.stacks[1] = ['C']
        self.stacks[2] = []

    def move(self, from_stack, to_stack):
        if self.stacks[from_stack]:
            block = self.stacks[from_stack].pop()
            self.stacks[to_stack].append(block)

    def get_stacks(self):
        return self.stacks

class BlockWorldApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Block World Problem")
        self.block_world = BlockWorld()
        self.create_widgets()
        self.draw_stacks()

    def create_widgets(self):
        self.canvas = tk.Canvas(self.root, width=400, height=300)
        self.canvas.pack()

        self.move_button = tk.Button(self.root, text="Move Block A from Stack 0 to Stack 1", command=self.move_block)
        self.move_button.pack()

        self.reset_button = tk.Button(self.root, text="Reset", command=self.reset_game)
        self.reset_button.pack()

    def draw_stacks(self):
        self.canvas.delete("all")
        stacks = self.block_world.get_stacks()
        for i, stack in stacks.items():
            for j, block in enumerate(stack):
                self.canvas.create_rectangle(i * 100 + 30, 250 - (j * 30), 
                                             i * 100 + 70, 250 - (j * 30 + 30), 
                                             fill="lightblue")
                self.canvas.create_text(i * 100 + 50, 250 - (j * 30 + 15), text=block)

    def move_block(self):
        # Move block A from stack 0 to stack 1
        if 'A' in self.block_world.stacks[0]:
            self.block_world.move(0, 1)
            self.draw_stacks()
        else:
            messagebox.showinfo("Error", "Block A is not in Stack 0.")

    def reset_game(self):
        self.block_world.create_initial_state()
        self.draw_stacks()

if __name__ == "__main__":
    root = tk.Tk()
    app = BlockWorldApp(root)
    root.mainloop()
