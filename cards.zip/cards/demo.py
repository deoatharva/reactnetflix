import cv2
import os

def extract_frames(video_path, output_folder, fps=3):
    # Create the output folder if it doesn't exist
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    # Open the video file
    video = cv2.VideoCapture(video_path)
    
    # Check if video opened successfully
    if not video.isOpened():
        print("Error: Could not open video.")
        return
    
    # Get the video properties
    video_fps = video.get(cv2.CAP_PROP_FPS)
    total_frames = int(video.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(video.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # Calculate interval between frames
    frame_interval = int(video_fps / fps)
    
    frame_number = 0
    image_number = 0
    
    while True:
        # Read the next frame
        ret, frame = video.read()
        
        # Break if no more frames
        if not ret:
            break
        
        # Save frame at the specified interval
        if frame_number % frame_interval == 0:
            image_filename = os.path.join(output_folder, f"frame_{image_number:04d}.jpg")
            cv2.imwrite(image_filename, frame)
            image_number += 1
        
        frame_number += 1
    
    # Release the video object
    video.release()
    print(f"Frames extracted and saved to {output_folder}")

if __name__ == "__main__":
    # Path to your video file
    video_path = 'video/v.mp4'
    # Folder where frames will be saved
    output_folder = 'extracted_frames'
    # Extract frames from the video
    extract_frames(video_path, output_folder, fps=3)
