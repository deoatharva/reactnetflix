import tkinter as tk
from PIL import Image, ImageTk
import random
import os

# Define the path to the image folder
IMAGE_FOLDER = 'images/'

# List of card image filenames
CARD_IMAGES = [
    '2_of_diamonds.jpg',
    '3_of_diamonds.jpg',
    '4_of_diamonds.jpg',
    '5_of_diamonds.jpg',
    '6_of_diamonds.jpg',
    '7_of_diamonds.jpg',
    '8_of_diamonds.jpg',
    '9_of_diamonds.jpg',
    '10_of_diamonds.jpg',
    'jack_of_diamonds.jpg',
    'queen_of_diamonds.jpg',
    'king_of_diamonds2.jpg',
    'ace_of_diamonds.jpg',
    '2_of_clubs.jpg',
    '3_of_clubs.jpg',
    '4_of_clubs.jpg',
    '5_of_clubs.jpg',
    '6_of_clubs.jpg',
    '7_of_clubs.jpg',
    '8_of_clubs.jpg',
    '9_of_clubs.jpg',
    '10_of_clubs.jpg',
    'jack_of_clubs.jpg',
    'queen_of_clubs.jpg',
    'king_of_clubs2.jpg',
    'ace_of_clubs.jpg',
    '2_of_spades.jpg',
    '3_of_spades.jpg',
    '4_of_spades.jpg',
    '5_of_spades.jpg',
    '6_of_spades.jpg',
    '7_of_spades.jpg',
    '8_of_spades.jpg',
    '9_of_spades.jpg',
    '10_of_spades.jpg',
    'jack_of_spades.jpg',
    'queen_of_spades.jpg',
    'king_of_spades2.jpg',
    'ace_of_spades.jpg',
    '2_of_hearts.jpg',
    '3_of_hearts.jpg',
    '4_of_hearts.jpg',
    '5_of_hearts.jpg',
    '6_of_hearts.jpg',
    '7_of_hearts.jpg',
    '8_of_hearts.jpg',
    '9_of_hearts.jpg',
    '10_of_hearts.jpg',
    'jack_of_hearts.jpg',
    'queen_of_hearts.jpg',
    'king_of_hearts2.jpg',
    'ace_of_hearts.jpg'

    # Add more cards as needed
]

# Initialize the main window
root = tk.Tk()
root.title("Card Shuffler")

# Create a label to display the card image
card_label = tk.Label(root)
card_label.pack(pady=20)

# Load all card images using Pillow
cards = [ImageTk.PhotoImage(Image.open(os.path.join(IMAGE_FOLDER, img))) for img in CARD_IMAGES]

def shuffle_cards():
    # Shuffle the cards
    random.shuffle(cards)
    # Display the first card from the shuffled list
    card_label.config(image=cards[0])

# Create a button to shuffle the cards
shuffle_button = tk.Button(root, text="Shuffle Cards", command=shuffle_cards)
shuffle_button.pack(pady=20)

# Initial display of a card
card_label.config(image=cards[0])

# Start the Tkinter main loop
root.mainloop()
